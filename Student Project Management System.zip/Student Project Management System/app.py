# ---------------- Add Column Helper ----------------
import sqlite3
import os

DB_NAME = "spms.db"
TABLE_NAME = "projects"
COLUMN_NAME = "guide_id"
COLUMN_TYPE = "INTEGER"

def add_column(db_name, table_name, column_name, column_type):
    if not os.path.exists(db_name):
        print(f" Database '{db_name}' not found!")
        return

    conn = sqlite3.connect(db_name)
    cur = conn.cursor()
    
    cur.execute(f"PRAGMA table_info({table_name})")
    columns = [info[1] for info in cur.fetchall()]
    
    if column_name in columns:
        print(f"⚠ Column '{column_name}' already exists in '{table_name}' table.")
    else:
        try:
            cur.execute(f"ALTER TABLE {table_name} ADD COLUMN {column_name} {column_type}")
            conn.commit()
            print(f" Column '{column_name}' added to '{table_name}' table.")
        except sqlite3.OperationalError as e:
            print(f" Error adding column: {e}")
    
    conn.close()

# ---------------- Flask App ----------------
from flask import Flask, render_template, redirect, url_for, request, session, g, flash, send_from_directory
from datetime import datetime
import json
from werkzeug.utils import secure_filename
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

app = Flask(__name__)
app.secret_key = "your_secret_key_here"

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

# ------------------ DB ------------------
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_NAME)
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(error):
    db = g.pop("db", None)
    if db:
        db.close()

def init_db():
    db = get_db()
    db.execute("""CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE,
        password TEXT,
        role TEXT,
        email TEXT
    )""")
    db.execute("""CREATE TABLE IF NOT EXISTS projects (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_name TEXT DEFAULT '[]',
        title TEXT,
        type TEXT DEFAULT 'individual',
        status TEXT DEFAULT 'Pending',
        feedback TEXT DEFAULT '[]',
        file_path TEXT,
        guide_id INTEGER
    )""")
    db.execute("""CREATE TABLE IF NOT EXISTS tasks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project_id INTEGER,
        task_title TEXT,
        deadline TEXT,
        status TEXT DEFAULT 'Pending'
    )""")
    db.execute("""CREATE TABLE IF NOT EXISTS messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project_id INTEGER,
        student_name TEXT,
        sender TEXT,
        message TEXT,
        timestamp TEXT
    )""")
    db.execute("""CREATE TABLE IF NOT EXISTS uploads (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project_id INTEGER,
        student_name TEXT,
        file_name TEXT,
        file_path TEXT,
        uploaded_at TEXT
    )""")
    db.commit()

# ------------------ Helper ------------------
def safe_json_load(s, default=[]):
    try:
        return json.loads(s)
    except:
        return default

def get_project_by_id(pid):
    db = get_db()
    proj = db.execute("SELECT * FROM projects WHERE id=?", (pid,)).fetchone()
    if proj:
        proj_dict = dict(proj)
        proj_dict["feedback"] = safe_json_load(proj_dict.get("feedback","[]"))
        proj_dict["student_name"] = safe_json_load(proj_dict.get("student_name","[]"))
        return proj_dict
    return None

def save_project(project):
    db = get_db()
    db.execute("UPDATE projects SET feedback=? WHERE id=?",
               (json.dumps(project["feedback"]), project["id"]))
    db.commit()


# ------------------ Email Helper ------------------
def send_email(to_email, subject, body):
    sender_email = "spms.coordinator@gmail.com"
    sender_password = "jjdwgglipbznhkjl"

    msg = MIMEMultipart()
    msg["From"] = "SPMS Coordinator <" + sender_email + ">"
    msg["To"] = to_email
    msg["Subject"] = subject
    msg.attach(MIMEText(body, "plain"))

    try:
        server = smtplib.SMTP("smtp.gmail.com", 587)
        server.starttls()
        server.login(sender_email, sender_password)
        server.sendmail(sender_email, to_email, msg.as_string())
        server.quit()
        print(f" Email sent to {to_email}")
    except Exception as e:
        print(" Email sending failed:", e)


# ------------------ Routes ------------------
@app.route("/")
def home():
    return render_template("index.html")

@app.route("/about")
def about():
    return render_template("about.html")

@app.route("/contact", methods=["GET", "POST"])
def contact():
    success = False
    if request.method == "POST":
        name = request.form["name"].strip()
        email = request.form["email"].strip()
        message = request.form["message"].strip()

        if not name or not email or not message:
            flash("⚠ All fields are required!", "danger")
            return render_template("contact.html", success=False)

        db = get_db()
        db.execute("""CREATE TABLE IF NOT EXISTS contact_messages (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        name TEXT,
                        email TEXT,
                        message TEXT,
                        timestamp TEXT
                    )""")
        db.execute("INSERT INTO contact_messages (name, email, message, timestamp) VALUES (?, ?, ?, ?)",
                   (name, email, message, datetime.now().strftime("%Y-%m-%d %H:%M")))
        db.commit()
        db.close()

        success = True
        flash(" Your message has been sent successfully!", "success")
        return render_template("contact.html", success=success)

    return render_template("contact.html", success=success)
@app.route("/view_messages")
def view_messages():
    if "user" not in session or session["role"] != "Admin":
        return redirect(url_for("login"))
    db = get_db()
    msgs = db.execute("SELECT * FROM contact_messages ORDER BY id DESC").fetchall()
    return render_template("admin_dashboard.html",
                           user=session["user"],
                           projects=[],
                           tasks=[],
                           approved_projects=0,
                           rejected_projects=0,
                           pending_projects=0,
                           completed_tasks=0,
                           in_progress_tasks=0,
                           pending_tasks=0,
                           uploads={},
                           messages=msgs)


@app.route("/login", methods=["GET","POST"])
def login():
    if request.method=="POST":
        u,p,r=request.form["username"],request.form["password"],request.form["role"]
        db=get_db()
        user=db.execute("SELECT * FROM users WHERE username=? AND password=? AND role=?",(u,p,r)).fetchone()
        if user:
            session["user"],session["role"]=u,r
            flash(f"Welcome {u}! You are logged in as {r}.","success")
            return redirect(url_for("dashboard"))
        return render_template("login.html",error="Invalid credentials or role!")
    return render_template("login.html")

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()
        email = request.form.get("email", "").strip()
        role = request.form.get("role", "").strip()
        
        # Basic validation
        if not username or not password or not email or not role:
            return render_template("register.html", error="All fields are required.")
        if role not in ["Student", "Guide", "Admin"]:
            return render_template("register.html", error="Please select a valid role.")
        db = get_db()

        # Check for duplicate username or email
        existing_user = db.execute("SELECT * FROM users WHERE username=? OR email=?", (username, email)).fetchone()
        if existing_user:
            return render_template("register.html", error="Username or email already exists.")
        try:
            db.execute("INSERT INTO users (username, password, role, email) VALUES (?, ?, ?, ?)",
                       (username, password, role, email))
            db.commit()
            flash("Registration successful. Please login.", "success")
            return redirect(url_for("login"))
        except sqlite3.OperationalError as e:
            return render_template("register.html", error=f"Database error: {e}")
    return render_template("register.html" )


@app.route("/dashboard")
def dashboard():
    if "user" not in session:
        return redirect(url_for("login"))
    role,user=session["role"],session["user"]
    db=get_db()
    today=datetime.today().date()

    if role=="Student":
        projects=[]
        for p in db.execute("SELECT * FROM projects").fetchall():
            students = safe_json_load(p["student_name"])
            if user in students:
                proj_dict = dict(p)
                proj_dict["student_name"] = students
                proj_dict["feedback"] = safe_json_load(proj_dict.get("feedback","[]"))
                guide_user = None
                if p["guide_id"]:
                    g = db.execute("SELECT username FROM users WHERE id=?",(p["guide_id"],)).fetchone()
                    if g: guide_user = g["username"]
                proj_dict["guide"] = guide_user
                projects.append(proj_dict)

        tasks=db.execute("""SELECT t.*,p.title AS project_title
                            FROM tasks t JOIN projects p ON t.project_id=p.id
                            WHERE ? IN (SELECT value FROM json_each(p.student_name))""",(user,)).fetchall()

        total=len(tasks)
        completed=len([t for t in tasks if t["status"]=="Completed"])
        progress=int((completed/total)*100) if total>0 else 0

        tasks_list=[]
        for t in tasks:
            td=dict(t)
            td["overdue"]=False
            if t["deadline"]:
                try:
                    d=datetime.strptime(str(t["deadline"]),"%Y-%m-%d").date()
                    td["overdue"]=(t["status"]!="Completed" and d<today)
                except: pass
            tasks_list.append(td)

        msgs=db.execute("SELECT * FROM messages WHERE student_name=? ORDER BY id DESC",(user,)).fetchall()
        uploads={p["id"]: db.execute("SELECT * FROM uploads WHERE project_id=? ORDER BY uploaded_at DESC",(p["id"],)).fetchall() for p in projects}

        guides = db.execute("SELECT id, username FROM users WHERE role='Guide'").fetchall()

        return render_template("student_dashboard.html",
                               user=user,projects=projects,tasks=tasks_list,
                               progress=progress,messages=msgs,uploads=uploads,
                               guides=guides)

    elif role=="Guide":
        projects=[]
        for p in db.execute("SELECT * FROM projects WHERE guide_id=(SELECT id FROM users WHERE username=?)",(user,)).fetchall():
            proj_dict = dict(p)
            proj_dict["student_name"] = safe_json_load(proj_dict.get("student_name","[]"))
            proj_dict["feedback"] = safe_json_load(proj_dict.get("feedback","[]"))
            proj_dict["guide"] = user
            projects.append(proj_dict)

        tasks_list=[]
        tasks=db.execute("""SELECT t.*,p.title AS project_title,p.student_name,p.id AS project_id
                            FROM tasks t JOIN projects p ON t.project_id=p.id
                            WHERE p.guide_id=(SELECT id FROM users WHERE username=?)""",(user,)).fetchall()
        for t in tasks:
            td=dict(t)
            td["overdue"]=False
            if t["deadline"]:
                try:
                    d=datetime.strptime(str(t["deadline"]),"%Y-%m-%d").date()
                    td["overdue"]=(t["status"]!="Completed" and d<today)
                except: pass
            tasks_list.append(td)

        uploads={p["id"]: db.execute("SELECT * FROM uploads WHERE project_id=? ORDER BY uploaded_at DESC",(p["id"],)).fetchall() for p in projects}

        return render_template("guide_dashboard.html",user=user,projects=projects,tasks=tasks_list,uploads=uploads)

    elif role == "Admin":
        projects = []
    for p in db.execute("SELECT * FROM projects").fetchall():
        proj_dict = dict(p)
        #  Convert student_name JSON string to list
        students = safe_json_load(proj_dict.get("student_name", "[]"))
        proj_dict["student_name"] = students
        proj_dict["feedback"] = safe_json_load(proj_dict.get("feedback", "[]"))

        guide_user = None
        if p["guide_id"]:
            g = db.execute("SELECT username FROM users WHERE id=?", (p["guide_id"],)).fetchone()
            if g:
                guide_user = g["username"]
        proj_dict["guide"] = guide_user

        projects.append(proj_dict)

    # Tasks fetch
    tasks = db.execute("""
        SELECT t.*, p.title AS project_title, p.student_name
        FROM tasks t
        JOIN projects p ON t.project_id = p.id
    """).fetchall()

    # Uploads
    uploads = {p["id"]: db.execute(
        "SELECT * FROM uploads WHERE project_id=? ORDER BY uploaded_at DESC", (p["id"],)
    ).fetchall() for p in projects}

    # Contact messages
    msgs = db.execute("SELECT * FROM contact_messages ORDER BY id DESC").fetchall()

    return render_template(
        "admin_dashboard.html",
        user=user,
        projects=projects,
        tasks=tasks,
        approved_projects=sum(1 for p in projects if p["status"] == "Approved"),
        rejected_projects=sum(1 for p in projects if p["status"] == "Rejected"),
        pending_projects=sum(1 for p in projects if p["status"] == "Pending"),
        completed_tasks=sum(1 for t in tasks if t["status"] == "Completed"),
        in_progress_tasks=sum(1 for t in tasks if t["status"] == "In Progress"),
        pending_tasks=sum(1 for t in tasks if t["status"] == "Pending"),
        uploads=uploads,
        messages=msgs  # ✅ pass messages to template
    )


# ------------------ Submit Project ------------------
@app.route("/submit_project", methods=["POST"])
def submit_project():
    if "user" not in session or session["role"] != "Student":
        return redirect(url_for("dashboard"))

    title = request.form["title"].strip()
    project_type = request.form.get("type", "individual")
    guide_id = request.form.get("guide_id")

    db = get_db()
    existing = db.execute("SELECT * FROM projects WHERE title=?", (title,)).fetchone()

    if existing:
        existing_type = existing["type"]
        students = safe_json_load(existing["student_name"])

        if existing_type == "individual":
            flash("⚠ This project already exists as an individual project!", "danger")
            return redirect(url_for("dashboard"))

        elif existing_type == "group":
            if session["user"] in students:
                flash("⚠ You have already submitted this project!", "warning")
                return redirect(url_for("dashboard"))
            if len(students) >= 2:
                flash("⚠ Maximum 2 students allowed for this group project.", "danger")
                return redirect(url_for("dashboard"))

            students.append(session["user"])
            db.execute("UPDATE projects SET student_name=?, guide_id=? WHERE id=?",
                       (json.dumps(students), guide_id, existing["id"]))
            db.commit()
            flash(f"You have joined the group project '{title}'!", "success")
            return redirect(url_for("dashboard"))

    else:
        db.execute("INSERT INTO projects (student_name, title, type, guide_id) VALUES (?, ?, ?, ?)",
                   (json.dumps([session["user"]]), title, project_type, guide_id))
        db.commit()
        flash(f"Project '{title}' submitted successfully!", "success")
        return redirect(url_for("dashboard"))


# ------------------ Upload/Download ------------------
@app.route("/upload_file/<int:pid>", methods=["POST"])
def upload_file(pid):
    if "user" not in session or session["role"] != "Student":
        return redirect(url_for("login"))
    if "file" not in request.files:
        flash("No file!", "danger")
        return redirect(url_for("dashboard"))

    f = request.files["file"]
    if f.filename == "":
        flash("No file selected!", "warning")
        return redirect(url_for("dashboard"))

    fname = secure_filename(f"{session['user']}_{pid}_{f.filename}")
    fpath = os.path.join(app.config["UPLOAD_FOLDER"], fname)
    f.save(fpath)

    db = get_db()
    db.execute(
        "INSERT INTO uploads (project_id, student_name, file_name, file_path, uploaded_at) VALUES (?,?,?,?,?)",
        (pid, session["user"], fname, fpath, datetime.now().strftime("%Y-%m-%d %H:%M")),
    )
    db.execute("UPDATE projects SET file_path=? WHERE id=?", (fpath, pid))
    db.commit()

    flash("File uploaded successfully!", "success")
    return redirect(url_for("dashboard"))

@app.route("/download_upload/<int:uid>")
def download_upload(uid):
    db = get_db()
    f = db.execute("SELECT * FROM uploads WHERE id=?", (uid,)).fetchone()
    if f:
        file_path = os.path.join(app.config["UPLOAD_FOLDER"], f["file_name"])
        if os.path.exists(file_path):
            return send_from_directory(app.config["UPLOAD_FOLDER"], f["file_name"], as_attachment=True)
        else:
            flash(f"⚠ File not found on server: {file_path}", "danger")
            return redirect(url_for("dashboard"))

    flash("File record not found in DB!", "danger")
    return redirect(url_for("dashboard"))


# ------------------ Approve/Reject ------------------
@app.route("/update_status/<int:pid>/<action>")
def update_status(pid,action):
    if "user" in session and session["role"]=="Guide":
        db=get_db()
        pr=db.execute("SELECT * FROM projects WHERE id=?",(pid,)).fetchone()
        if pr:
            if action=="approve":
                db.execute("UPDATE projects SET status='Approved' WHERE id=?",(pid,))
            elif action=="reject":
                db.execute("UPDATE projects SET status='Rejected' WHERE id=?",(pid,))
            db.commit()
            flash("Status updated!","info")
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))


# ------------------ Task Assignment ------------------
@app.route("/assign_task/<int:pid>",methods=["POST"])
def assign_task(pid):
    if "user" in session and session["role"]=="Guide":
        t, d = request.form["task_title"], request.form["deadline"]
        ds = None
        try:
            ds = datetime.strptime(d,"%Y-%m-%d").strftime("%Y-%m-%d")
        except:
            ds = "Not specified"

        db = get_db()
        db.execute("INSERT INTO tasks (project_id,task_title,deadline) VALUES (?,?,?)",(pid,t,ds))
        db.commit()

        guide_name = session["user"]
        proj = db.execute("SELECT student_name FROM projects WHERE id=?",(pid,)).fetchone()
        if proj:
            students = safe_json_load(proj["student_name"])
            for s in students:
                user = db.execute("SELECT * FROM users WHERE username=?",(s,)).fetchone()
                if user and user["email"]:
                    subject = f"New Task Assigned by {guide_name}"
                    body = f"""Hello {s},

A new task has been assigned for your project.

Task: {t}
Deadline: {ds}

Assigned by: {guide_name}

-- Project Management System (Coordinator)
"""
                    send_email(user["email"], subject, body)

        flash("Task assigned & student notified by email!","success")
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))

@app.route("/update_task/<int:tid>/<status>")
def update_task(tid,status):
    if "user" in session and session["role"]=="Student":
        db=get_db()
        db.execute("UPDATE tasks SET status=? WHERE id=?",(status,tid))
        db.commit()
        flash("Task updated!","info")
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))


# ------------------ Messaging ------------------
@app.route("/send_message/<int:pid>",methods=["POST"])
def send_message(pid):
    if "user" in session and session["role"]=="Guide":
        txt=request.form.get("message")
        pr=get_project_by_id(pid)
        if pr:
            pr["feedback"].append({"sender":"Guide","message":txt,"timestamp":datetime.now().strftime("%Y-%m-%d %H:%M")})
            save_project(pr)
            db=get_db()
            db.execute("INSERT INTO messages (project_id,student_name,sender,message,timestamp) VALUES (?,?,?,?,?)",
                       (pid,json.dumps(pr["student_name"]),"Guide",txt,datetime.now().strftime("%Y-%m-%d %H:%M")))
            db.commit()
        flash("Message sent!","success")
    return redirect(url_for("dashboard"))


# ------------------ Forgot Password ------------------
@app.route("/forgot", methods=["GET","POST"])
def forgot():
    if request.method == "POST":
        username = request.form["username"].strip()
        db = get_db()
        user = db.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        if user:
            flash("Password reset link sent to your email (demo).","info")
            return redirect(url_for("login"))
        else:
            return render_template("forgot.html", error="Username not found.")
    return render_template("forgot.html")


# ------------------ Logout ------------------
@app.route("/logout")
def logout():
    session.clear()
    flash("Logged out!","info")
    return redirect(url_for("home"))


# ------------------ Run ------------------
if __name__ == "__main__":
    # Ensure the guide_id column exists
    add_column(DB_NAME, TABLE_NAME, COLUMN_NAME, COLUMN_TYPE)
    
    # Initialize DB tables
    with app.app_context():
        init_db()
    
    # Run Flask app
    app.run(debug=True)
